# Future Skills Lab – Orientador de Carreira

Sistema em Python orientado a objetos que recomenda carreiras com base em competências avaliadas pelo usuário.

## Execução
```
python3 main.py
```

## Estrutura
- models/
- data/
- services/
- main.py
