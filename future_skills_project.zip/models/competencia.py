class Competencia:
    def __init__(self, nome, nivel):
        self.nome = nome
        self.nivel = nivel
